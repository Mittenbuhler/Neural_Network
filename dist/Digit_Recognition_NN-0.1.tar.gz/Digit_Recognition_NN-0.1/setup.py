from setuptools import setup
 
setup(
    name='Digit_Recognition_NN',    
    version='0.1',                         
    scripts=['nn_functions.py', 'install_network.py', 'digit_recognition.py']
    )